﻿function logout() {
    localStorage.clear();
    window.location.href = "login.html";
}
function login() {
    $("#error").addClass("d-none");

    $.ajax({
        url: "/api/auth/login",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            email: $("#email").val(),
            password: $("#password").val()
        }),
        success: function (res) {
            localStorage.setItem("token", res.token);
            localStorage.setItem("userId", res.userId);
            localStorage.setItem("userName", res.name);

            window.location.href = "/index.html";
        },
        error: function () {
            $("#error").removeClass("d-none");
        }
    });
}

function logout() {
    localStorage.clear();
    window.location.href = "/login.html";
}
