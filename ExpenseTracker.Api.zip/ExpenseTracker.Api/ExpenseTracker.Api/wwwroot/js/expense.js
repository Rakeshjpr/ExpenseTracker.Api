﻿const expenseApi = "https://localhost:7038/api/expenses";

let allExpenses = [];
let currentPage = 1;
const pageSize = 5;

// =======================
// AUTH CHECK
// =======================
const token = localStorage.getItem("token");

if (!token) {
    window.location.href = "login.html";
}

// Attach JWT token to ALL requests
$.ajaxSetup({
    headers: {
        "Authorization": "Bearer " + token
    }
});

// =======================
// PAGE LOAD
// =======================
$(document).ready(function () {
    loadExpenses();
    loadSummary();
});

// =======================
// LOAD EXPENSES (MY)
// =======================
function loadExpenses() {
    $.ajax({
        url: `${expenseApi}/my`,
        type: "GET",
        success: function (data) {
            allExpenses = data;
            currentPage = 1;

            renderPaginated();   // 🔥 THIS WAS MISSING
            loadChart(data);
            loadSummary();
        },
        error: function () {
            alert("Failed to load expenses");
        }
    });
}


// =======================
// RENDER TABLE (SINGLE SOURCE)
// =======================
function renderTable(data) {
    $("#expenseList").empty();

    if (!data || data.length === 0) {
        $("#expenseList").html(`
            <tr>
                <td colspan="5" class="text-center text-muted">
                    No records found
                </td>
            </tr>
        `);
        return;
    }

    data.forEach(e => {
        const date = new Date(e.expenseDate).toLocaleDateString();

        $("#expenseList").append(`
            <tr>
                <td>${date}</td>
                <td>${e.title}</td>
                <td>
                    <span class="badge bg-info">${e.category}</span>
                </td>
                <td class="fw-bold text-success">₹${e.amount}</td>
                <td>
                    <button class="btn btn-warning btn-sm me-1"
                        onclick='openEditModal(${JSON.stringify(e)})'>
                        Edit
                    </button>
                    <button class="btn btn-danger btn-sm"
                        onclick="deleteExpense(${e.id})">
                        Delete
                    </button>
                </td>
            </tr>
        `);
    });
 
}

// =======================
// ADD EXPENSE
// =======================
function addExpense() {
    $.ajax({
        url: expenseApi,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            title: $("#title").val(),
            amount: parseFloat($("#amount").val()),
            category: $("#category").val(),
            expenseDate: $("#date").val()
        }),
        success: function () {
            loadExpenses();
            loadSummary();

            $("#title").val("");
            $("#amount").val("");
            $("#date").val("");
        },
        error: function () {
            alert("Error adding expense");
        }
    });
}

// =======================
// DELETE EXPENSE
// =======================
function deleteExpense(id) {
    if (!confirm("Delete this expense?")) return;

    $.ajax({
        url: `${expenseApi}/${id}`,
        type: "DELETE",
        success: function () {
            loadExpenses();
            loadSummary();
        }
    });
}

// =======================
// FILTER BY DATE
// =======================
function filterByDate() {
    const from = $("#fromDate").val();
    const to = $("#toDate").val();

    if (!from || !to) {
        alert("Please select both From and To dates");
        return;
    }

    $.ajax({
        url: `${expenseApi}/filter?from=${from}&to=${to}`,
        type: "GET",
        success: function (data) {
            renderTable(data);
        },
        error: function () {
            alert("Filter failed");
        }
    });
}

// =======================
// RESET FILTER
// =======================
function resetFilter() {
    $("#fromDate").val("");
    $("#toDate").val("");
    loadExpenses();
}

// =======================
// DASHBOARD SUMMARY
// =======================
function loadSummary() {
    $.ajax({
        url: `${expenseApi}/summary`,
        type: "GET",
        success: function (data) {
            $("#totalExpense").text(data.totalExpense);
            $("#monthExpense").text(data.thisMonthTotal);
        },
        error: function (err) {
            console.error(err);
            alert("Failed to load summary");
        }
    });
}
function openEditModal(expense) {
    $("#editId").val(expense.id);
    $("#editTitle").val(expense.title);
    $("#editAmount").val(expense.amount);
    $("#editCategory").val(expense.category);
    $("#editDate").val(expense.expenseDate.split("T")[0]);

    const modal = new bootstrap.Modal(
        document.getElementById("editModal")
    );
    modal.show();
}
function updateExpense() {
    const id = $("#editId").val();

    const payload = {
        title: $("#editTitle").val(),
        amount: parseFloat($("#editAmount").val()),
        category: $("#editCategory").val(),
        expenseDate: $("#editDate").val()
    };

    $.ajax({
        url: `${expenseApi}/${id}`,
        type: "PUT",
        contentType: "application/json",
        data: JSON.stringify(payload),
        success: function () {
            // Close modal
            bootstrap.Modal.getInstance(
                document.getElementById("editModal")
            ).hide();

            // Reload UI
            loadExpenses();
            loadSummary();
        },
        error: function (err) {
            console.error(err);
            alert("Update failed");
        }
    });
}
let categoryChart = null;

function loadChart(expenses) {

    const canvas = document.getElementById("categoryChart");
    if (!canvas) return;

    if (!expenses || expenses.length === 0) {
        if (categoryChart) {
            categoryChart.destroy();
            categoryChart = null;
        }
        return;
    }

    const totals = {};

    expenses.forEach(e => {
        if (!e.category || !e.amount) return;
        totals[e.category] = (totals[e.category] || 0) + e.amount;
    });

    const labels = Object.keys(totals);
    const values = Object.values(totals);

    if (categoryChart) {
        categoryChart.destroy();
    }

    categoryChart = new Chart(canvas, {
        type: "pie",
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: [
                    "#2563eb", // blue
                    "#16a34a", // green
                    "#f59e0b", // amber
                    "#dc2626", // red
                    "#6b7280"  // gray
                ]

            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}


function renderPagination() {
    const totalPages = Math.ceil(allExpenses.length / pageSize);
    $("#pagination").empty();

    if (totalPages <= 1) return;

    $("#pagination").append(`
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="prevPage()">Previous</a>
        </li>
    `);

    for (let i = 1; i <= totalPages; i++) {
        $("#pagination").append(`
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="goToPage(${i})">${i}</a>
            </li>
        `);
    }

    $("#pagination").append(`
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="nextPage()">Next</a>
        </li>
    `);
}

function goToPage(page) {
    currentPage = page;
    renderPaginated();
}



function nextPage() {
    if (currentPage * pageSize < allExpenses.length) {
        currentPage++;
        renderPaginated();
    }
}

function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        renderPaginated();
    }
}
function renderPaginated() {
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;

    const pageData = allExpenses.slice(start, end);

    renderTable(pageData);
    renderPagination();
}



