﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExpenseTracker.Api.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Password",
                table: "Users",
                newName: "password_hash");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Expenses",
                newName: "user_id");

            migrationBuilder.RenameColumn(
                name: "ExpenseDate",
                table: "Expenses",
                newName: "expense_date");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "password_hash",
                table: "Users",
                newName: "Password");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "Expenses",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "expense_date",
                table: "Expenses",
                newName: "ExpenseDate");
        }
    }
}
