﻿using ExpenseTracker.Api.Data;
using ExpenseTracker.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq; // ✅ THIS WAS MISSING
using System.Security.Claims;

[Authorize]
[ApiController]
[Route("api/expenses")]
public class ExpensesController : ControllerBase
{
    private readonly AppDbContext _context;

    public ExpensesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        return Ok(_context.Expenses.ToList());
    }

   

[HttpPost]
public IActionResult Add([FromBody] Expense expense)
{
    var userId = int.Parse(
        User.FindFirst(ClaimTypes.NameIdentifier)!.Value
    );

    expense.UserId = userId;

    // Safety: ensure date is set
    if (expense.ExpenseDate == default)
        expense.ExpenseDate = DateTime.Now;

    _context.Expenses.Add(expense);
    _context.SaveChanges();

    return Ok(expense);
}



[HttpPut("{id}")]
    public IActionResult Update(int id, Expense expense)
    {
        var existing = _context.Expenses.Find(id);
        if (existing == null) return NotFound();

        existing.Title = expense.Title;
        existing.Amount = expense.Amount;
        existing.Category = expense.Category;
        existing.ExpenseDate = expense.ExpenseDate;

        _context.SaveChanges();
        return Ok(existing);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var expense = _context.Expenses.Find(id);
        if (expense == null) return NotFound();

        _context.Expenses.Remove(expense);
        _context.SaveChanges();
        return Ok();
    }

    // ✅ USER-WISE EXPENSES
    [HttpGet("my")]
    public IActionResult GetMyExpenses()
    {
        var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value);

        var expenses = _context.Expenses
            .Where(e => e.UserId == userId)
            .OrderByDescending(e => e.ExpenseDate)
            .ToList();

        return Ok(expenses);
    }
    // =======================
    // DASHBOARD SUMMARY
    // =======================
    [HttpGet("summary")]
    public IActionResult GetSummary()
    {
        var userId = int.Parse(
            User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value
        );

        var totalExpense = _context.Expenses
            .Where(e => e.UserId == userId)
            .Sum(e => (decimal?)e.Amount) ?? 0;

        var now = DateTime.Now;

        var thisMonthTotal = _context.Expenses
            .Where(e => e.UserId == userId &&
                        e.ExpenseDate.Month == now.Month &&
                        e.ExpenseDate.Year == now.Year)
            .Sum(e => (decimal?)e.Amount) ?? 0;

        return Ok(new
        {
            totalExpense,
            thisMonthTotal
        });
    }
    [HttpGet("filter")]
    public IActionResult Filter(DateTime from, DateTime to)
    {
        var userId = int.Parse(
            User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value
        );

        var expenses = _context.Expenses
            .Where(e => e.UserId == userId &&
                        e.ExpenseDate >= from &&
                        e.ExpenseDate <= to)
            .OrderByDescending(e => e.ExpenseDate)
            .ToList();

        return Ok(expenses);
    }





}
