﻿namespace ExpenseTracker.Api.Models
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
        public string NewPassword { get; set; }
    }
}
