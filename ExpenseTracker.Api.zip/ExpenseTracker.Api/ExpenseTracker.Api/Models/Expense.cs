﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ExpenseTracker.Api.Models {
public class Expense
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public decimal Amount { get; set; }
    public string Category { get; set; } = "";
        [Column("expense_date")]
        public DateTime ExpenseDate { get; set; }

        [Column("user_id")]
        public int UserId { get; set; }
    }
}
